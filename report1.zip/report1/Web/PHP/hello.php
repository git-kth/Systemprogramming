<?php
	echo "Hello PHP World\n!";
?>
